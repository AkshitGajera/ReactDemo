import React from 'react'

function Itemlist9(props) {
    let listt = props.item
    return (
        <>
        <div>
            <ul>
                {listt.map((it)=>(
                    <li>{it}</li>
                ))}
            </ul>
        </div>
        </>
    )
}

export default Itemlist9
