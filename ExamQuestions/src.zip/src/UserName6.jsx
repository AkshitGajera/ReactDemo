import React from 'react'
import { useState } from 'react'
function UserName6() {
    const [input, setinput] = useState("nothing")
    let inputed = (event) => {
        setinput(event.target.value)
    }
    return (
        <>
        <div>
            Name : <input type="text" onChange={inputed}/>
            <p>Entered Name : {input}</p>
        </div>
        </>
    )
}

export default UserName6
